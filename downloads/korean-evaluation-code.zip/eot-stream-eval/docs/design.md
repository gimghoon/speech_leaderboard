# 한국어 은행 문의 EOT 연속 입력 파일럿

사용자는 한국어 자동 선별 데이터에서 160개 파일럿 목록을 만들고, 연속 입력 평가기를 연결하고, 무음 타이머·Smart Turn v3.2·LiveKit v1-mini를 실행하는 제안을 승인했다. 학습·외부 음성 API·영어 평가·웹 공개는 포함하지 않는다.

한국어 선별342개 중 EOT/HOLD/내용·잘림의 자동 상태가 auto_consistent 또는 not_applicable이고, 명시적 EOT 무음이 200ms 이상인160개를 선택한다. 모두 pseudo annotation이며 human_verified=false를 유지한다. 원본 파일/기존결과는 변경하지 않는다. 언어 보류235개 및 영어15개는 이번평가에 쓰지 않는다.

16kHz float32 mono로만 모델 입력을 만든다. 원본8kHz WAV는 byte-identical로 복사하고 모델 입력만 causal polyphase FIR로 변환한다 (upfirdn,2*firwin(41,.5,Kaiser5), up2, 출력first2*N, delay20/16000=1.25ms, delay보정없음). wholewave centered FIR는prefix경계에서미래샘플누출이있어사용하지않는다. 개발셋은 고정revision LiveKit한국어 validation377개다. 개발셋으로만 모델별 policy를 선택해 저장한 뒤 MInDS160을 평가하며, MInDS 결과로 임계값을 재선택하지 않는다.

공통 Silero ONNX VAD를 원본 순서대로512sample(32ms)씩 수행한다. 상태는 음성마다 초기화한다. >=.5 speech onset/resume, <.35 silence candidate, 그 사이 값은 상태 유지. 한 번도 음성을 감지하지 않았으면 종료하지 않는다. 연속무음96ms 이후 silence state, 최초 낮은 frame의 시작을 silence_start로 추정한다. 미래frame을 보지 않고 frame 끝 시각에만 결정한다. 모든 모델은 동일한 VAD trace를 사용한다.

EOT모델은 관찰된 무음200ms 후 처음 호출하고 이후200ms마다 호출한다. inference input은 해당시각까지 받은 PCM뿐이며 정답·전체길이·전사는 전달하지 않는다. Smart Turn8초/mini1.2초 context는 기존 pinned local adapters를 그대로 사용한다. 매32ms VAD frame에서 model policy는 min_wait에 도달하고 현재지역에서 관찰한 최신 score >=threshold이면 종료하고, timeout에 도달하면 종료한다. Timer는 wait를 지난 첫VADframe에서 종료한다. 말이 재개되면 score와 무음시간을 초기화한다.

파일별 첫 종료만 실제 outcome으로 사용한다. < eot_s (1e-9 numeric tolerance)는 premature, >= eot_s는 correct, 관찰종료까지 출력이 없으면 missed다. 실제 label의 HOLD는 보조분석과 분모 보고에 사용하고 VAD/모델의 판단시점 선택에는 사용하지 않는다. 판정지연은 audio timeline 기준이며 CPU 실행시간을 별도로 보고한다. 실제 wall-clock end-to-end 시스템 지연이라고 부르지 않는다.

녹음 후반 무음 길이의 차이를 통제하기 위해 관찰종료는 reference EOT+4초로 통일한다. 필요한 경우 원본 파일 끝 뒤에 digital silence를 inference buffer에만 추가한다. 기존 WAV와 주석은 고치지 않는다. 추가한 초수와 원본 끝 이후에 선언된 비율을 별도로 기록하고, 결과는 '종료 후 통제된 무음 조건'이라고 명시한다. 32ms 미만 마지막 미완성frame은 모델에 미래padding해 넣지 않고 생략한다.

개발셋 정책 grid: threshold0..1 step.01, min_wait [.2,.4,.6,.8,1.0], timeout [1,1.5,2,2.5,3,3.5] (>=min_wait); timer wait .2..3.5 step.1. 선택 목표는 premature rate<=5%/10%, miss rate<=5%. feasible 중 premature/miss를각4초 loss로 둔 penalized mean delay를 최소화한다. 동률은 miss, premature, model threshold/min_wait/timeout 또는 timerwait의 사전순으로 결정한다. feasible없으면 제약위반최소->penalizedloss로 fallback하고 infeasible로 분명히표시한다.

보고:160개 공통ID, EOT/HOLD 수, 모델별 개발설정/실제 MInDS 잘림률/미검출률/정상종료 평균지연/penalizedmean 지연/실행시간p50,p95, sample별 처음종료시각, VAD 오류·타이머·모델·timeout 이유, 원본끝뒤선언 여부, scoretrace/모델hash/데이터hash/protocol version. 개발셋377개와 테스트160개의 score/ID를 섞지 않는다. 공개 원본과 자동 주석을 쓴 파일럿이며 공식 비공개 평가나 gold 정확도가 아니다.

구현은 독립 새폴더 eot-stream-eval에서 한다. 기존 모델adapter와 데이터loader만 verbatim복사해 pinned runtime을 재사용한다. 원본 모델weights는 기존 cache를 사용한다. 전체 결과는 minds-ko-pilot-stream-v1에 저장한다.

참조EOT/HOLD를 만들 때 사용한Silero VAD와 이번공통VAD는동일가중치를사용한다. 따라서이결과는독립정답검증이아니며VAD정답의모델의존성을포함한자동주석파일럿이다. 정상종료평균지연은조건부이므로항상전체분모잘림/미검출률과4초penalizedloss를함께표시한다.
