# Korean Streaming EOT Pilot Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build and run a causal Korean-only160turn pilot for three local endpoint detectors with settings chosen only on377LiveKit Korean development turns.
**Architecture:** Immutable source manifests feed common causal Silero VAD traces and prefix-only model score traces; a pure policy replay selects configurations on development and applies them unchanged to the pilot. Independent data and policy modules have disjoint ownership and one final reviewer audits integration.
**Tech Stack:** Existing Python3.12 eot-venv, NumPy, SciPy, ONNXRuntime, datasets, pinned native LiveKit runtime.
**Spec:** ../../design.md

## Global Constraints
- Korean only; no training, no external audio API, no source/oldoutput mutation.
- Original model revisions and source hashes pinned; source WAVs unchanged.
- Frame512/16k; >=.5speech, <.35quiet,96msconfirmation; firstmodelscore at200mssilence then200mspoll; resetscore upon speech.
- Prefix-only input and actual first decision; no label metadata reaches model or VAD scheduler.
- Reference EOT+4s observation horizon; declared digital silence after sourceEOF only; inference time reported separately.
- Freeze policies on377development before pilot inference. All3models compare same160IDs.

## Review Focus
- Silence before firstspeech and resumed speech must not produce false zero-age events.
- Prefix inputs never contain samples later than timestamp or previous-turn state.
- Gate clock32ms and score clock200ms must quantize causally and timeouts work between score ticks.
- Pseudolabels retain explicit HOLD/EOT meaning and no lastHOLD-to-EOT relabeling.
- Nonfinite/failed scores, missing records and stale cache hashes fail closed; no partial synthetic scores reported.

### Task1: Data snapshot
Files eot_stream/data.py, eot_stream/livekit_data.py, tests/test_data.py.
Interfaces: build_pilot(source_root,output_root)->summary; load_pilot_turns(pilot_root)->list[dict]; load_dev_turns(cache_dir)->list[dict]. Turn dict: id,split,audio(float32mono16k),eot_s,hold_spans(start/end),original_duration_s,source_audio_sha256,label_type.
- [ ] REDtests exclusions by each uncertainty axis, explicitEOT >=.2, sourcehash and duplicatedID rejection; no relabeling; resamplinglength.
- [ ] Implement bytecopy160snapshot+all342selectionlog with preservation/provenance; dev377pinnedloader.
- [ ] GREENwholedata suite; verifyactual160/91HOLD and original hashes.

### Task2: Pure policy replay and development selection
Files eot_stream/policy.py, tests/test_policy.py.
Interfaces: first_decision(frames,policy)->dict|None; evaluate_policy(traces,refs,policy)->dict with metrics/per_turn; select_policy(traces,refs,kind,target)->dict policy/feasible/dev_metrics. Frame dicttimestamp_s,silence_age_s,region_id,p_eot(latestobservedscore orNone),is_score_event,source_end_s optional. Ref id/eot_s/hold_spans/original_duration_s/horizon_s.
- [ ] REDhandfixtures threshold/delay/timeout/reset/firstdecision, equalEOTboundary, misses, penalizedloss and feasible/fallbackselection.
- [ ] Implement exactdesign grids and deterministicties. No model imports or testsetselection.
- [ ] GREENsuite.

### Task3: Causal VAD and prefix scoring
Files eot_stream/stream.py, models.py, tests/test_stream.py.
Interfaces: SileroFrames.infer(audio)->list probabilities forcomplete512frames; gate_frames(probs)->list frames including onlyquiet frames with age>=.2; score_frames(audio,gate,detector)->frames preservingcurrentp andreset perregion; make_observation(turn)->(buffer,ref).
- [ ] REDfixtures leadingquiet/resume/hysteresis, prefixspy, clipwindowownership, finitevalidation, appenddisclosure andnoincompletefuturepadding.
- [ ] Implement pinnedSilero state/context and oldadapters; addelapsedinference fields andcacheprotocolhashes.
- [ ] GREENsuite andlocalmodel smoke.

### Task4: Run, report and audit
Files eot_stream/cli.py, report.py, tests/test_cli.py, README.txt.
- [ ] REDintegrationfixtures completeIDs, failclosednewoutput, devselectionbeforetestmodelcalls, honestlabels/outputcoverage.
- [ ] Implement resumable permodel/perturn caches+hashes; generatedtables andfilelogs.
- [ ] Run actual377dev+160pilot all3models, sameprotocol; inspectcomplete manifests/modelhashes andsourcepreservation.
- [ ] Fresh independent review of code+results, fix meaningfulfindings RED->GREEN andfullsuite.
- [ ] Package user-facing source/results, Korean report; no websitepublish.
